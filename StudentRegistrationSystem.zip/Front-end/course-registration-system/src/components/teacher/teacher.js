import * as React from 'react';

export default function Teacher() {

    return (
        <>
        
        </>
    );
}